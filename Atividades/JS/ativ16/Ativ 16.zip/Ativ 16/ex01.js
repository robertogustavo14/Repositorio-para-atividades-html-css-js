var n1 = 1
var resultado = n1 + 1
console.log (resultado)