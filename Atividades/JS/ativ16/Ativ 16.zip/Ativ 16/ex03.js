var valcigarro = 20/7 //20 cigarros por maço , 7 reais por maço = valor por cigarro 
var valano = (valcigarro * 17) * 365 // 17 cigarros por dia x 365 dias
var res = valano * 76 // tempo medio de vida é 76 anos
console.log ("R$",res)