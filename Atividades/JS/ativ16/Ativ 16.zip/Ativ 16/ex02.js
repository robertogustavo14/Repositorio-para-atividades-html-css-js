var n1 = 10
var n2 = 10
var n3 = 10
res = (n1+n2+n3)/3
if (res>=7) {
    console.log ("Voce esta aprovado!!!")
}
if (res < 7 && res >5) {
    console.log ("Voce esta em recuperação")
}
if (res<5) {
    console.log ("Voce esta reprovado")
}
