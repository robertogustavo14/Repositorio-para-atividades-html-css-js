var pi = 3.14
var raio = 2
var altura = 10
var area = pi * (raio**2)
var volume = pi*(raio**2)*altura

console.log ("A area do cilindro é: ", area)
console.log ("O volume do cilindro é: ", volume)