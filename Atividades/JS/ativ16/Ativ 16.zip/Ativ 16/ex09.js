var nome = "pedro"
if (nome === "gustavo") {
 console.log ("Nome Correto")
} else {
 console.log ("Nome incorreto")
}