var A = 15
var B = 15
if (A>B) {
console.log("A é maior que B.")
}
if (A<B) {
console.log("A é menor que B.")
}
if (A===B) {
console.log("A é igual a B.")
}