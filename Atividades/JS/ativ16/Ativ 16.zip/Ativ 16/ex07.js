var n1 = 20
var n2 = 10
var n3 = 30
var resu = n2+n3
if (resu<n1) {
    console.log("O primeiro numero é maior que a soma do segundo e o terceiro.")
}
if (resu>n1) {
    console.log("O primeiro numero é menor que a soma do segundo e o terceiro.")
}