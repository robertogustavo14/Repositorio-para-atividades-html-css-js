var x = 10
var y = 4
console.log("O quociente da divisao é:",y)
console.log("O resto da divisao é:",x % y)
