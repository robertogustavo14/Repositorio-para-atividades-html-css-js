var n1 = 10
var n2 = 8
var soma = n1+n2
var pro = n1*n2
var quo = n1 % n2
console.log ("A)",soma)
console.log ("B)",pro)
console.log ("C)",quo)